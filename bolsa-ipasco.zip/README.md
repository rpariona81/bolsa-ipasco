# bolsa-ipasco
Bolsa laboral actualizada IDEX PASCO
