<!--<footer class="footer">-->
<footer class="footer fixed-bottom">
    <div class="container px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; IESTP Ricardo Ramos Plata</div>
        </div>
    </div>
</footer>



</body>

</html>